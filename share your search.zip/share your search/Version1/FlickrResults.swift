//
//  FlickrResults.swift
//  UpgradedSleepingInTheLibrary
//
//  Created by Raj Balani on 25/07/19.
//  Copyright © 2019 balani. All rights reserved.
//

import Foundation

struct apiSearchResults {
    let searchTerm : String
    let searchResults : [FlickrPhoto]
}
