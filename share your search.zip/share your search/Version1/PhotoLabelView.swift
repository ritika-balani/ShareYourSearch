//
//  PhotoLabelView.swift
//  UpgradedSleepingInTheLibrary
//
//  Created by Raj Balani on 25/07/19.
//  Copyright © 2019 balani. All rights reserved.
//

import UIKit

class FlickrPhotoLabelView: UICollectionReusableView {
        
  @IBOutlet weak var titleLabel: UILabel!
  
}
